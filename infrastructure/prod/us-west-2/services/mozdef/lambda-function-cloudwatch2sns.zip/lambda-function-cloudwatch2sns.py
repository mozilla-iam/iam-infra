var message = {};
var sns = new AWS.SNS();
sns.publish({
    TopicArn: "arn:aws:sns:us-west-2:320464205386:logs2MozDef",
    Message: JSON.stringify(message)
}, function(err, data) {
    if(err) {
        console.error('error publishing to SNS');
        context.fail(err);
    } else {
        console.info('message published to SNS');
        context.succeed(null, data);
    }
});

